package com.oibsip.oibsip.quiz

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.oibsip.oibsip.quiz.databinding.ActivityMainBinding

data class Question(val text: String, val options: List<String>, val correct: Int)

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val questions = listOf(
        Question("What is 2 + 2?", listOf("3","4","5","2"), 1),
        Question("Kotlin is developed by?", listOf("JetBrains","Google","Microsoft","Oracle"), 0),
        Question("Android's recommended language is?", listOf("Java","Kotlin","C++","Python"), 1)
    )
    private var index = 0
    private var score = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        showQuestion()
        binding.btnNext.setOnClickListener {
            val checked = when {
                binding.rb1.isChecked -> 0
                binding.rb2.isChecked -> 1
                binding.rb3.isChecked -> 2
                binding.rb4.isChecked -> 3
                else -> -1
            }
            if (checked == -1) {
                Toast.makeText(this, "Select an answer", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (checked == questions[index].correct) score++
            index++
            if (index >= questions.size) {
                val i = Intent(this, ResultActivity::class.java)
                i.putExtra("score", score)
                i.putExtra("total", questions.size)
                startActivity(i)
                finish()
            } else {
                showQuestion()
            }
        }
    }

    private fun showQuestion() {
        val q = questions[index]
        binding.tvQuestion.text = q.text
        binding.rb1.text = q.options[0]
        binding.rb2.text = q.options[1]
        binding.rb3.text = q.options[2]
        binding.rb4.text = q.options[3]
        binding.rg.clearCheck()
    }
}
