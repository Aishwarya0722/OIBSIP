package com.oibsip.oibsip.notes

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.oibsip.oibsip.notes.databinding.ItemNoteBinding

class NotesAdapter(
    private val items: List<Note>,
    private val onClick: (Int)->Unit,
    private val onDelete: (Int)->Unit
) : RecyclerView.Adapter<NotesAdapter.VH>() {

    inner class VH(val binding: ItemNoteBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemNoteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val n = items[position]
        holder.binding.tvTitle.text = n.title
        holder.binding.root.setOnClickListener { onClick(position) }
        holder.binding.btnDelete.setOnClickListener { onDelete(position) }
    }

    override fun getItemCount(): Int = items.size
}
