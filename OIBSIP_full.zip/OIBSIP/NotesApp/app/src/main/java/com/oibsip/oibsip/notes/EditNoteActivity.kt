package com.oibsip.oibsip.notes

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.oibsip.oibsip.notes.databinding.ActivityEditNoteBinding
import org.json.JSONArray
import org.json.JSONObject

class EditNoteActivity : AppCompatActivity() {
    private lateinit var binding: ActivityEditNoteBinding
    private val PREFS = "notes_prefs"
    private val KEY = "notes"
    private var noteId = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)
        noteId = intent.getLongExtra("id", -1L)
        val title = intent.getStringExtra("title") ?: ""
        val body = intent.getStringExtra("body") ?: ""
        binding.etTitle.setText(title)
        binding.etBody.setText(body)
        binding.btnSave.setOnClickListener {
            val t = binding.etTitle.text.toString().trim()
            val b = binding.etBody.text.toString().trim()
            if (t.isEmpty()) {
                Toast.makeText(this, "Title required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            saveNote(noteId, t, b)
            finish()
        }
    }

    private fun saveNote(id: Long, title: String, body: String) {
        val pref = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val s = pref.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(s)
        val newArr = JSONArray()
        var usedId = id
        if (usedId < 0) usedId = System.currentTimeMillis()
        var replaced = false
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optLong("id", -1) == usedId) {
                val no = JSONObject()
                no.put("id", usedId)
                no.put("title", title)
                no.put("body", body)
                newArr.put(no)
                replaced = true
            } else {
                newArr.put(o)
            }
        }
        if (!replaced) {
            val no = JSONObject()
            no.put("id", usedId)
            no.put("title", title)
            no.put("body", body)
            newArr.put(no)
        }
        pref.edit().putString(KEY, newArr.toString()).apply()
    }
}
