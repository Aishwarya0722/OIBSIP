package com.oibsip.oibsip.notes

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.oibsip.oibsip.notes.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject

data class Note(var id: Long, var title: String, var body: String)

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val PREFS = "notes_prefs"
    private val KEY = "notes"
    private val notes = mutableListOf<Note>()
    private lateinit var adapter: NotesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadNotes()
        adapter = NotesAdapter(notes, onClick = { pos ->
            val n = notes[pos]
            val i = Intent(this, EditNoteActivity::class.java)
            i.putExtra("id", n.id)
            i.putExtra("title", n.title)
            i.putExtra("body", n.body)
            startActivity(i)
        }, onDelete = { pos ->
            notes.removeAt(pos)
            adapter.notifyItemRemoved(pos)
            saveNotes()
        })
        binding.rv.layoutManager = LinearLayoutManager(this)
        binding.rv.adapter = adapter

        binding.btnAdd.setOnClickListener {
            val i = Intent(this, EditNoteActivity::class.java)
            startActivity(i)
        }
    }

    override fun onResume() {
        super.onResume()
        notes.clear()
        loadNotes()
        adapter.notifyDataSetChanged()
    }

    private fun saveNotes() {
        val arr = JSONArray()
        for (n in notes) {
            val o = JSONObject()
            o.put("id", n.id)
            o.put("title", n.title)
            o.put("body", n.body)
            arr.put(o)
        }
        val pref = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        pref.edit().putString(KEY, arr.toString()).apply()
    }

    private fun loadNotes() {
        val pref = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val s = pref.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(s)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            notes.add(Note(o.optLong("id", System.currentTimeMillis()), o.getString("title"), o.getString("body")))
        }
    }
}
