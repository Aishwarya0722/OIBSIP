package com.oibsip.oibsip.todo

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.oibsip.oibsip.todo.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject

data class TodoItem(var title: String, var done: Boolean = false)

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val PREFS = "todo_prefs"
    private val KEY = "todos"
    private val todos = mutableListOf<TodoItem>()
    private lateinit var adapter: TodoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadTodos()
        adapter = TodoAdapter(todos,
            onToggle = { pos ->
                todos[pos].done = !todos[pos].done
                adapter.notifyItemChanged(pos)
                saveTodos()
            },
            onDelete = { pos ->
                todos.removeAt(pos)
                adapter.notifyItemRemoved(pos)
                saveTodos()
            }
        )
        binding.rv.layoutManager = LinearLayoutManager(this)
        binding.rv.adapter = adapter

        binding.btnAdd.setOnClickListener {
            val text = binding.etTask.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, "Enter a task", Toast.LENGTH_SHORT).show()
            } else {
                todos.add(0, TodoItem(text))
                adapter.notifyItemInserted(0)
                binding.etTask.text.clear()
                saveTodos()
            }
        }
    }

    private fun saveTodos() {
        val arr = JSONArray()
        for (t in todos) {
            val o = JSONObject()
            o.put("title", t.title)
            o.put("done", t.done)
            arr.put(o)
        }
        val pref = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        pref.edit().putString(KEY, arr.toString()).apply()
    }

    private fun loadTodos() {
        val pref = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val s = pref.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(s)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            todos.add(TodoItem(o.getString("title"), o.optBoolean("done", false)))
        }
    }
}
