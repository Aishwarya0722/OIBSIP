package com.oibsip.oibsip.todo

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.oibsip.oibsip.todo.databinding.ItemTodoBinding

class TodoAdapter(
    private val items: List<TodoItem>,
    private val onToggle: (Int)->Unit,
    private val onDelete: (Int)->Unit
) : RecyclerView.Adapter<TodoAdapter.VH>() {

    inner class VH(val binding: ItemTodoBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemTodoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val t = items[position]
        holder.binding.tvTitle.text = t.title
        holder.binding.cbDone.isChecked = t.done
        holder.binding.cbDone.setOnClickListener { onToggle(position) }
        holder.binding.btnDelete.setOnClickListener { onDelete(position) }
    }

    override fun getItemCount(): Int = items.size
}
