# OIBSIP
This repository contains three Android starter projects (Kotlin):
- ToDoApp: add/delete/mark tasks
- QuizApp: multiple choice quiz
- NotesApp: add/edit/delete notes

How to open:
- Unzip this folder.
- Open Android Studio -> Open an existing project -> select the subfolder (e.g., ToDoApp/app).
- Let Android Studio sync Gradle and generate ViewBinding classes.
